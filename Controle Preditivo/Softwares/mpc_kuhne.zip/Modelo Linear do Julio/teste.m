function teste(A,B,N)

for i = 2 : N
    Abar = [Abar ; A^i];
end
